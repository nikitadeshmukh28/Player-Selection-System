package com.cg.playerselectionbyspringmvc.dto;
import java.util.ArrayList;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
/**
 * @Entity Indicates that a class declares as a Entity.
 * @Table Annotation is used for creating table as name Game. 
 * 
 * @author nikitadeshmukh
 *
 */

@Entity
@Table(name="Game")
public class Game {
	//this is used to create primary key.
	@Id
    @Column(name="gameId")
	private int gameId;
	public int getGameId() {
		return gameId;
	}
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}
	//@Column will create the column in table with given name.
	@Column(name="gamename")
	private String name;
	//This will used to create one game with many players that is for making relationship.
	@OneToMany(targetEntity=Player.class)
	//@JoinColumn is used to create one joinColumn instead of creating the third table.
	@JoinColumn(name="gameId")
	//declare the list of players.
	private List<Player> myplayerlist=new ArrayList<Player>();
	//this is used to display the game object.
	@Override
	
	public String toString() {
		return "Game [gameId=" + gameId + ", name=" + name + ", myplayerlist=" + myplayerlist + "]";
	}
	//This is parameterized constructor.
	public Game(int gameId, String name, List<Player> myplayerlist) {
		super();
		this.gameId = gameId;
		this.name = name;
		this.myplayerlist = myplayerlist;
	}
	public Game() {
		super();
		// TODO Auto-generated constructor stub
	}
	//this is get method for gamename.
	public String getName() {
		return name;
	}
	//this is used for set the gamename
	public void setName(String name) {
		this.name = name;
	}
	//this is used for get list of players.
	public List<Player> getMyplayerlist() {
		return myplayerlist;
	}
	//this is used to set list of players.
	public void setMyplayerlist(List<Player> myplayerlist) {
		this.myplayerlist = myplayerlist;
	}
	
}



