package com.cg.playerselectionbyspringmvc.exception;
/**
 * This is the Exception Class which is used to print the exception message from Player.
 * @author nikitade
 *
 */
public class PlayerException extends RuntimeException{
	public PlayerException() {
		super();
	}
	public PlayerException(String msg) {
		super(msg);
	}
}

