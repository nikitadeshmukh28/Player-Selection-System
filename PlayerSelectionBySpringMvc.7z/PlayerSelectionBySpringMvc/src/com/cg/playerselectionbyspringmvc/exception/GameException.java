package com.cg.playerselectionbyspringmvc.exception;
/**
 * This is the Exception Class which is used to print the exception message from Game.
 * @author nikitade
 *
 */
public class GameException extends RuntimeException{
	public GameException() {
		super();
	}
	
	public GameException(String msg) {
		super(msg);
	}
}


