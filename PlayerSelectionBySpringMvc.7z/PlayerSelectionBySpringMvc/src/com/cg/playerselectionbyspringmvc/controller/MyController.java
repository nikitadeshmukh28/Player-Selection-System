package com.cg.playerselectionbyspringmvc.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.playerselectionbyspringmvc.dto.Game;
import com.cg.playerselectionbyspringmvc.dto.Player;
import com.cg.playerselectionbyspringmvc.exception.GameException;
import com.cg.playerselectionbyspringmvc.exception.PlayerException;
import com.cg.playerselectionbyspringmvc.service.GameService;
import com.cg.playerselectionbyspringmvc.service.PlayerService;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
/**
 * This is the Controller Class and it is Annoted by @Controller
 * @author nikitade
 *
 */

@Controller
public class MyController {
	/**
	 * @Autowired is used to inject properties of PlayerService.
	 */
	@Autowired
	PlayerService playerService;
	/**
	 * @Autowired is used to inject properties of GameService.
	 */
	@Autowired
	GameService gameService;
	
	/**
	 * @RequestMapping Annotation is used  for mapping web requests onto methods.
	 * @return the view with name listpage.
	 * 
	 *
	 */
	@RequestMapping(name="listpage",method=RequestMethod.GET)
	public String WelcomePage() {
		return "listpage";

	}

  /**
   * this method will return the view with name addplayer.
   * 
   */
	@GetMapping("addpage")
	public ModelAndView getAddplayer(@ModelAttribute("player") Player p) {

		return new ModelAndView("addplayer");

	}

	 /**
	   * this method will return the view with name showplayer.
	   * 
	   */
	@GetMapping("showpage")
	public ModelAndView showPlayer() {
		List<Player> myAllPlayer = playerService.showAllPlayer();
		return new ModelAndView("showplayer", "list", myAllPlayer);
	}

	 /**
	   * this method will return the view with name success.
	   * 
	   */
	@PostMapping("addplayer")
	public ModelAndView addproduct(@ModelAttribute("player") Player p)  {
		Player pl = null;
		
				pl = playerService.addPlayer(p);
		
		return new ModelAndView("success", "key", pl);

	}
	
	 /**
	   * this method will return the view with name addgame.
	   * 
	   */
	@GetMapping("addgame")
	public ModelAndView getAddgame(@ModelAttribute("game") Game g) {

		return new ModelAndView("addgame");

	}
 
	 /**
	   * this method will return the view with name showgamejsp.
	   * 
	   */
	@GetMapping("showgamepage")
	public ModelAndView showGame() {
		List<Game> myAllGame = gameService.showAll();
		return new ModelAndView("showgamejsp", "gamelist", myAllGame);
	}
	
	 /**
	   * this method will return the view with name successg.
	   * 
	   */
	@PostMapping("addgame")
	public ModelAndView addgame(@ModelAttribute("game") Game g) {
		
		Game gm=gameService.addGame(g);
		return new ModelAndView("successg", "gamekey", gm);

	}
	
	 /**
	   * this method will return the view with name searchpId.
	   * 
	   */
	
	@GetMapping("searchplayerId")
	public ModelAndView search() {
		return new ModelAndView("searchpId");
	}
	 /**
	   * this method will return the view with name searchpId.
	   * 
	   */
	@PostMapping("searchpId")
	public ModelAndView getSearchPlayer(@RequestParam("playerId") int id, Model m) {
		Player play=playerService.searchById(id);
		m.addAttribute("inf", play);
		return new ModelAndView("searchpId","inf", play);

	}
	 /**
	   * this method will return the view with name showplayers.
	   *
	   */
	
	@GetMapping("searchplayerskill")
	public ModelAndView searchs() {
		return new ModelAndView("showplayers");
	}
	 /**
	   * this method will return the view with name showplayers.
	   *
	   */
	@PostMapping("showplayers")
	public ModelAndView getSearchPlayers(@RequestParam("skill") String ski, Model m) {
		List<Player> plays=playerService.searchBySkill(ski);
		m.addAttribute("infs", plays);
		return new ModelAndView("showplayers", "infs", plays);

	}
	
	 /**
	   * this method will return the view with name showgames.
	   * 
	   */
	@GetMapping("searchgamename")
	public ModelAndView searchsg() {
		return new ModelAndView("showgames");
	}
	 /**
	   * this method will return the view with name showgames.
	   * 
	   */
	@PostMapping("showgames")
	public ModelAndView getSearchGames(@RequestParam("name") String gamename, Model m) {
		
		List<Game> gameskills=gameService.searchByName(gamename);
		m.addAttribute("games", gameskills);
		return new ModelAndView("showgames", "games",gameskills);
		}
	
	/**
	  * @ExceptionHandler Annotation used for handling Game exceptions which are thrown from this controller class.
	  * 
	  * @return model means the new view error/generic_error.
	  */
	@ExceptionHandler(GameException.class)
	public ModelAndView handlegameException(GameException ex) {

		ModelAndView model = new ModelAndView("error/generic_error");
		
		model.addObject("errMsg", ex.getMessage());

		return model;

	}
	
	 /**
	  * @ExceptionHandler Annotation used for handling player exceptions which are thrown from this controller class.
	  * 
	  * @return model means the new view error/generic_error.
	  */
	
	@ExceptionHandler(PlayerException.class)
	public ModelAndView handlePlayerException(PlayerException ex) {

		ModelAndView model = new ModelAndView("error/generic_error");
		
		model.addObject("errMsg", ex.getMessage());

		return model;

	}
	
	
	}


