package com.cg.playerselectionbyspringmvc.dao;

import java.util.List;

import com.cg.playerselectionbyspringmvc.dto.Game;
import com.cg.playerselectionbyspringmvc.exception.GameException;

public interface GameDao {
	public boolean save(Game game);

	public List<Game> findByName(String name)  ;

	public List<Game> findAll();
}
