package com.cg.playerselectionbyspringmvc.dao;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.playerselectionbyspringmvc.dto.Player;
import com.cg.playerselectionbyspringmvc.exception.PlayerException;
/**
 * @Repository Indicates that a class declares as a Repository and also it consider as a bean.
 * @author nikitadeshmukh
 *
 */


@Repository
public class PlayerDaoImpl implements PlayerDao{
	@PersistenceContext
	EntityManager entitymanager;
	/**
	 * This is the saveplayer method which add the player in database.
	 * @Exception when we want to add the same player in database having same Id it will through Exception.
	 * @param here object of player is passed as argument.
	 * @return boolean value true if player added.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public boolean save(Player p) {
		// TODO Auto-generated method stub
		Query query = entitymanager.createQuery("FROM Game gameId WHERE gamename =?1");         //Execute the Query
		query.setParameter(1,p.getSkill());
		List result = query.getResultList();
		if(result.size()==1) {
			try {
				entitymanager.persist(p);
				entitymanager.flush();
		   Query queryone= entitymanager.createQuery("update Player set gameId=?1 where player_skill=?2");
		   queryone.setParameter(1,query.getSingleResult());
		   queryone.setParameter(2,p.getSkill());
		  queryone.executeUpdate();
			}catch (Exception e) {
				throw new PlayerException("OOPs Error Occured! player id already exist please try with another Id");}}
			else if(result.isEmpty()) {
				try {
				entitymanager.persist(p);
				entitymanager.flush();
				}catch (Exception e) {
					throw new PlayerException("OOPs Error Occured! player id already exist please try with another Id");}
			}
				
		return true;
	}

	/**
	 * This is the searchbySkill method which searches the players whose skill are match with given skill.
	 * @Exception when we want to retrieve the player  which is not yet saved it throws the exception Game With this skill is not found.
	 * @param here skill is passed as argument.
	 * @return List of player.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public List<Player> findbyskill(String skill) {
		Query query=entitymanager.createQuery("From Player Where player_skill=?1");
		query.setParameter(1,skill);
		List<Player> myList=query.getResultList();
		/**
		 * if player is not found method will throw exception.
		 *
		 * 
		 */ 
		if (myList.isEmpty()) {
			throw new PlayerException("OOPs Error Occured! Player not found for this skill");
		}
		return myList;
	}

	/**
	 * This is the searchbyId method which searches the player whose Id is match with given Id.
	 * @Exception when we want to retrieve the player  which is not yet saved with that id it throws the exception Player is not found with this Id.
	 * @param here playerId is passed as argument.
	 * @return object of player.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public Player findById(int playerId) {
     Player p;
		
		Query query=entitymanager.createQuery("From Player Where playerId=?1");

		query.setParameter(1,playerId);
		try {
		p=(Player) query.getSingleResult();
		}catch (NoResultException e) {
			
			throw new PlayerException("OOPs Error Occured! player with this id is not found");}
		return p;
	}

	/**
	 * This is the showAllPlayer  method which searches the All players .
	 * @param here no argument is passed.
	 * @return List of player.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public List<Player> showAllPlayer() {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("FROM Player");
		List<Player> myList=query.getResultList();
		return myList;
	}

	
	}


