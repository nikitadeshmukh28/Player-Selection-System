package com.cg.playerselectionbyspringmvc.dao;

import java.util.ArrayList;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.playerselectionbyspringmvc.dto.Game;
import com.cg.playerselectionbyspringmvc.dto.Player;
import com.cg.playerselectionbyspringmvc.exception.GameException;

/**
 * @Repository Indicates that a class declares as a Repository and also it consider as a bean.
 * @author nikitadeshmukh
 *
 */
@Repository
public class GameDaoImpl implements GameDao{
	@PersistenceContext
	EntityManager entitymanager;
    PlayerDaoImpl daos;
    /**
	 * This is the savegame method which add the game in database.
	 * @Exception when we want to add the same game in database having same Id it will through Exception.
	 * @param here object of game is passed as argument.
	 * @return boolean value true if game added.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public boolean save(Game game) {
		try {
		// TODO Auto-generated method stub
		entitymanager.persist(game);
		entitymanager.flush();
		Query queryone= entitymanager.createQuery("update Player set gameId=?1 where player_skill=?2");
		   queryone.setParameter(1,game.getGameId());
		   queryone.setParameter(2,game.getName());
		  queryone.executeUpdate();
		}catch (Exception e) {
			throw new GameException("OOPs Error Occured! Game id already exist please try with another Id");}
		return true;
	}

	
	/**
	 * This is the searchbyName method which searches the games whose names are match with given name.
	 * @Exception when we want to retrieve the game  which is not yet saved it throws the exception Game With this name is not found.
	 * @param here name of game is passed as argument.
	 * @return List of game.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public List<Game> findByName(String name) {
List<Game> gameList;
		
		Query query=entitymanager.createQuery("From Game Where gamename=?1");
		query.setParameter(1,name);
		gameList=query.getResultList();
		
		if(gameList.isEmpty())
			throw new GameException("OOPs Error Occured! Game with this name is not found");
		return gameList;
		
	}

	
	/**
	 * This is the findAll method which searches the All games .
	 * @param here no argument is passed.
	 * @return List of game.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public List<Game> findAll() {
		// TODO Auto-generated method stub
		Query query=entitymanager.createQuery("FROM Game");
		List<Game> myList=query.getResultList();
	     return myList;
	}

}



