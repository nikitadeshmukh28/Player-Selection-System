package com.cg.playerselectionbyspringmvc.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.playerselectionbyspringmvc.dto.Player;
import com.cg.playerselectionbyspringmvc.exception.PlayerException;

public interface PlayerDao {
	public boolean save(Player p) ;

	public List<Player> findbyskill(String skill)  ;

	public Player findById(int playerId)  ;
    public List<Player> showAllPlayer();
}
