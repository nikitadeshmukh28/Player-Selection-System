package com.cg.playerselectionbyspringmvc.service;

import java.util.List;

import com.cg.playerselectionbyspringmvc.dto.Game;
import com.cg.playerselectionbyspringmvc.exception.GameException;


public interface GameService {

	public Game addGame(Game game) throws GameException;

	public List<Game> searchByName(String name) throws GameException;

	public List<Game> showAll();
}
