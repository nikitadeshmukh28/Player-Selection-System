package com.cg.playerselectionbyspringmvc.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.playerselectionbyspringmvc.dao.GameDao;
import com.cg.playerselectionbyspringmvc.dto.Game;
import com.cg.playerselectionbyspringmvc.exception.GameException;
/**
 * @Service Indicates that a class declares as a Service and also it consider as a bean.
 * @Transactional annotation provides the application the ability to declaratively 
 * control transaction .
 * @author nikitade
 *
 */
@Service
@Transactional
public class GameServiceImpl implements GameService{
	@Autowired
	GameDao dao;
	
	public GameServiceImpl() {
		super();
	}
	  /**
		 * This is the savegame method which add the game in database.
		 * @Exception when we want to add the same game in database having same Id it will through Exception.
		 * @param here object of game is passed as argument.
		 * @return game object if game added.
		 * @author nikitade
		 */ 
	@Override
	public Game addGame(Game game) throws GameException{
		// TODO Auto-generated method stub
		dao.save(game);
		return game;
	}

	/**
	 * This is the searchbyName method which searches the games whose names are match with given name.
	 * @Exception when we want to retrieve the game  which is not yet saved it throws the exception Game With this name is not found.
	 * @param here name of game is passed as argument.
	 * @return List of game.
	 * @author nikitade
	 */ 
	@Override
	public List<Game> searchByName(String name) throws GameException {
		// TODO Auto-generated method stub
		return dao.findByName(name);
	}


	/**
	 * This is the findAll method which searches the All games .
	 * @param here no argument is passed.
	 * @return List of game.
	 * @author nikitade
	 */ 
	@Override
	public List<Game> showAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
