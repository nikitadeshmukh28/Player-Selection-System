package com.cg.playerselectionbyspringmvc.service;

import java.sql.SQLException;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.playerselectionbyspringmvc.dao.PlayerDao;
import com.cg.playerselectionbyspringmvc.dto.Player;
import com.cg.playerselectionbyspringmvc.exception.PlayerException;
/**
 * @Service Indicates that a class declares as a Service and also it consider as a bean.
 * @Transactional annotation provides the application the ability to declaratively 
 * control transaction .
 * @author nikitade
 *
 */
@Service
@Transactional
public class PlayerServiceImpl implements PlayerService{
	@Autowired
	PlayerDao dao;
	
	/**
	 * This is the addplayer method which add the player in database.
	 * @Exception when we want to add the same player in database having same Id it will through Exception.
	 * @param here object of player is passed as argument.
	 * @return boolean value true if player added.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public Player addPlayer(Player p) throws PlayerException{
		// TODO Auto-generated method stub
		dao.save(p);
		return p;
	}

	/**
	 * This is the searchbyId method which searches the player whose Id is match with given Id.
	 * @Exception when we want to retrieve the player  which is not yet saved with that id it throws the exception Player is not found with this Id.
	 * @param here playerId is passed as argument.
	 * @return object of player.
	 * @author nikitadeshmukh
	 */ 
	
	@Override
	public Player searchById(int playerId) throws PlayerException{
		// TODO Auto-generated method stub
		return dao.findById(playerId);
	}

	
	/**
	 * This is the searchbySkill method which searches the players whose skill are match with given skill.
	 * @Exception when we want to retrieve the player  which is not yet saved it throws the exception Game With this skill is not found.
	 * @param here skill is passed as argument.
	 * @return List of player.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public List<Player> searchBySkill(String skill) throws PlayerException{
		// TODO Auto-generated method stub
		return dao.findbyskill(skill);
	}

	/**
	 * This is the showAllPlayer  method which searches the All players .
	 * @param here no argument is passed.
	 * @return List of player.
	 * @author nikitadeshmukh
	 */ 
	
	@Override
	public List<Player> showAllPlayer() {
		// TODO Auto-generated method stub
		return dao.showAllPlayer();
	}

}
