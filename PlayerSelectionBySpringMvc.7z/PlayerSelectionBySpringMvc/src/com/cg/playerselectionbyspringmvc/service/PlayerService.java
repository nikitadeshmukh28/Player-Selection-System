package com.cg.playerselectionbyspringmvc.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.playerselectionbyspringmvc.dto.Player;
import com.cg.playerselectionbyspringmvc.exception.PlayerException;

public interface PlayerService {

	public Player addPlayer(Player p) throws PlayerException;

	public Player searchById(int playerId) throws PlayerException;

	public List<Player> searchBySkill(String skill) throws PlayerException;
	public List<Player> showAllPlayer();
}
