package com.cg.playerselectiondb.util;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import com.cg.playerselectiondb.exception.GameException;
public class DButil {
  static Connection conn;
	public static Connection getConnection() throws GameException
	{
		Properties ps=new Properties();
		try {
			InputStream it= new FileInputStream("src/main/resources/jdbc.properties");
			ps.load(it);
			if(ps!=null)
				
			{
		String	driver=ps.getProperty("jdbc.driver");
		String	url=ps.getProperty("jdbc.url");
		String	uname=ps.getProperty("jdbc.username");
		String	pass=ps.getProperty("jdbc.password");
		
		Class.forName(driver);
		 conn=	DriverManager.getConnection(url,uname,pass);
			}
		} catch (FileNotFoundException e) {
			
			throw new GameException("file not found");
			// TODO Auto-generated catch block
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			
			throw new GameException("file not found");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
			throw new GameException("file not found");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			
			throw new GameException("file not found");
		}
		return conn;
	}
	
	
	
}
