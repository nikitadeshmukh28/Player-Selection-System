package com.cg.playerselectiondb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import com.cg.playerselctiondb.dto.Player;
import com.cg.playerselectiondb.exception.GameException;
import com.cg.playerselectiondb.exception.PlayerException;
import com.cg.playerselectiondb.util.DButil;

public class playerdaoImpl implements Playerdao {

	public boolean save(Player p) throws SQLException, PlayerException {
		Connection con = DButil.getConnection();
		String game_exist = "select gameId from game where gamename in(?) ";
		PreparedStatement pst;
		pst = con.prepareStatement(game_exist);
		pst.setString(1, p.getSkill());
		ResultSet result = pst.executeQuery();
		if (result.next()) {
			String querya = "insert into player(g_gameId,playername,playerId,playerskill) values((select gameId from game where gamename=?),?,?,?)";

			PreparedStatement pstm = con.prepareStatement(querya);
         try {
			pstm.setString(1, p.getSkill());
			pstm.setString(2, p.getName());
			pstm.setInt(3, p.getPlayerId());
			pstm.setString(4, p.getSkill());
			pstm.executeUpdate();
         }catch (SQLException e) {
				throw new PlayerException("player id already exist");}
			pstm.close();

			con.close();
		} else {

			String query = "insert into player(playername,playerId,playerskill) values(?,?,?)";
			PreparedStatement playerquery = null;

			try {
				playerquery = con.prepareStatement(query);
				playerquery.setString(1, p.getName());
				playerquery.setInt(2, p.getPlayerId());
				playerquery.setString(3, p.getSkill());
				playerquery.executeUpdate();
			} catch (SQLException e) {
				throw new PlayerException("player id already exist");
			} finally {
				try {
					playerquery.close();
					con.close();
				} catch (SQLException e) {

				}
			}
		}

		return true;
	}

	public List<Player> findbyskill(String skill) throws PlayerException {
		Connection con = DButil.getConnection();
		String query_show = "select playerId,playername,playerskill from Player where playerskill=?";
		// prepare the statement for obtaining data form database.
		PreparedStatement pstm = null;
		List<Player> mylist = new ArrayList<Player>();
		try {

			pstm = con.prepareStatement(query_show);
			pstm.setString(1, skill);
			// this resultset has the result(rows) which is fetched from database.
			ResultSet result = pstm.executeQuery();

			while (result.next()) {
				Player emp = new Player();
				emp.setPlayerId(result.getInt("playerId"));
				emp.setName(result.getString("playerName"));
				emp.setSkill(result.getString("playerskill"));
				mylist.add(emp);
			}
		} catch (SQLException e) {
			
		} 
		finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
			}
		}
		
		if (mylist.isEmpty()) {
			throw new PlayerException("Player not found for this skill");
		}
		return mylist;
	}

	public Player findById(int playerId) throws PlayerException {
		// TODO Auto-generated method stub
		Connection con = DButil.getConnection();
		String query_show = "select playerId,playername,playerskill from Player where playerId=?";

		PreparedStatement pstm = null;
		Player p = new Player();
		try {
			// prepare the statement for obtaining data form database.
			pstm = con.prepareStatement(query_show);
			pstm.setInt(1, playerId);
			// this resultset has the result(rows) which is fetched from database.
			ResultSet result = pstm.executeQuery();
			while (result.next()) {
				p.setPlayerId(result.getInt("playerId"));
				p.setName(result.getString("playerName"));
				p.setSkill(result.getString("playerskill"));
			}
		} catch (SQLException e) {
			
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
			}
		}
		if (p.getPlayerId() == (playerId))
			return p;
		throw new PlayerException("Id not Found");
		
	}

	public List<Player> findAll() {
		// TODO Auto-generated method stub
		Connection con = DButil.getConnection();
		String query_show = "select playerId,playername,playerskill from Player";
		PreparedStatement pstm = null;
		List<Player> mylist = new ArrayList<Player>();
		try {
			// prepare the statement for obtaining data form database.
			pstm = con.prepareStatement(query_show);
			// this resultset has the result(rows) which is fetched from database.
			ResultSet result = pstm.executeQuery();

			while (result.next()) {
				Player emp = new Player();
				emp.setPlayerId(result.getInt("playerId"));
				emp.setName(result.getString("playerName"));
				emp.setSkill(result.getString("playerskill"));
				mylist.add(emp);
			}
		} catch (SQLException e) {
			
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				
			}
		}
		return mylist;
	}

}
