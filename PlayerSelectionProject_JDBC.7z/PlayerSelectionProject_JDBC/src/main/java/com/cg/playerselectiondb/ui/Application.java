package com.cg.playerselectiondb.ui;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.cg.playerselctiondb.dto.Game;
import com.cg.playerselctiondb.dto.Player;
import com.cg.playerselctiondb.service.GameServiceImpl;
import com.cg.playerselctiondb.service.PlayerServiceImpl;
import com.cg.playerselectiondb.exception.GameException;
import com.cg.playerselectiondb.exception.PlayerException;
import com.cg.playerselectiondb.util.DButil;

public class Application {
	static GameServiceImpl service;
	static PlayerServiceImpl serviceone;

	public Application() {

	}

	public static void main(String args[]) throws SQLException, PlayerException {
		Scanner scr = new Scanner(System.in);
		service = new GameServiceImpl();
		serviceone = new PlayerServiceImpl();
		int choice = 0;
		do {
			System.out.println("1.add player");
			System.out.println("2.show All Player");
			System.out.println("3.search player by skill");
			System.out.println("4.search player by Id");
			System.out.println("5.Add Game");
			System.out.println("6.Show All Game");
			System.out.println("7.Search game by name");
			System.out.println("Enter the choice");
			choice = scr.nextInt();
			switch (choice) {

			case 1:
				System.out.println("enter id");
				int id = scr.nextInt();

				System.out.println("enter name");
				String name = scr.next();

				System.out.println("enter skill ");
				String sal = scr.next();

				Player emp = new Player();
				emp.setPlayerId(id);
				emp.setName(name);
				emp.setSkill(sal);
				try {
				serviceone.addPlayer(emp);
				}catch (PlayerException e) {

					System.out.println(e.getMessage());
				}
				System.out.println("Id is    " + emp.getPlayerId());
				System.out.println("Name is  " + emp.getName());
				System.out.println("Skill is" + emp.getSkill());
				System.out.println("");
				break;
			case 2:
				List<Player> myList = serviceone.showAll();
				for (Player empData : myList) {
					System.out.println("");
					System.out.println("Id is    " + empData.getPlayerId());
					System.out.println("Name is  " + empData.getName());
					System.out.println("Skill is" + empData.getSkill());
					System.out.println("");
				}
				break;
			case 3:
				System.out.println("enter any game name as skill");
				String skill = scr.next();
				List<Player> myListone = null;
				try {
					myListone = serviceone.searchBySkill(skill);
					for (Player empData : myListone) {
						System.out.println("");
						System.out.println("Id is    " + empData.getPlayerId());
						System.out.println("Name is  " + empData.getName());
						System.out.println("Skill is  " + empData.getSkill());
					}
				} catch (PlayerException e) {

					System.out.println(e.getMessage());
				}
				System.out.println("");
				break;

			case 4:
				System.out.println("enter id");
				int id1 = scr.nextInt();

				try {
					Player myplayer = serviceone.searchById(id1);

					System.out.println(myplayer);

				} catch (PlayerException e) {

					System.out.println(e.getMessage());
				}
				System.out.println("");
				break;

			case 5:
				System.out.println("Enter game name");
				String namegame = scr.next();
				System.out.println("Enter game Id");
				int gameId = scr.nextInt();
				Game gm = new Game();
				gm.setName(namegame);
				gm.setGameId(gameId);
				try {
					service.addGame(gm);
				} catch (GameException e) {

					System.out.println(e.getMessage());
				}

				System.out.println("The list of players");
				try {
					List<Player> player = serviceone.searchBySkill(namegame);
					Game game = new Game(gameId, namegame, player);
					try {
						service.addGame(game);
					} catch (GameException e) {
						System.out.println(player);
					}
				} catch (PlayerException e) {
					System.out.println("player not found");
				}

				break;

			case 6:
				List<Game> myListgame = service.showAll();
				for (Game empData : myListgame) {
					System.out.println("");
					System.out.println("Id is    " + empData.getGameId());
					System.out.println("Name is  " + empData.getName());
					System.out.println("The list of players ");
					try {
						List<Player> player = serviceone.searchBySkill(empData.getName());
						System.out.println(player);
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}

				}

				break;

			case 7:

				System.out.println("enter Game name");
				String gamenames = scr.next();

				try {
					List<Game> mygame = service.searchByName(gamenames);
					for (Game empData : mygame) {
						System.out.println("Id is    " + empData.getGameId());
						System.out.println("Name is  " + empData.getName());
						System.out.println("The list of players");
						List<Player> player = serviceone.searchBySkill(empData.getName());
						System.out.println(player);
					}

				} catch (PlayerException e) {
					System.out.println(e.getMessage());
				} catch (GameException e) {

					System.out.println(e.getMessage());
				}

				break;

			}

		} while (choice != 0);

	}
}
