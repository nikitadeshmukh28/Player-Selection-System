package com.cg.playerselectiondb.dao;

import java.sql.SQLException;
import java.util.List;

import com.cg.playerselctiondb.dto.Player;
import com.cg.playerselectiondb.exception.GameException;
import com.cg.playerselectiondb.exception.PlayerException;

public interface Playerdao {
	public boolean save(Player p) throws SQLException, PlayerException ;
	public List<Player> findbyskill(String skill) throws PlayerException;
	public Player findById(int playerId) throws PlayerException;
	public List<Player> findAll();
}
