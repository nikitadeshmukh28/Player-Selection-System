package com.cg.playerselectiondb.dao;
import java.sql.SQLException;
import java.util.List;

import com.cg.playerselctiondb.dto.Game;
import com.cg.playerselectiondb.exception.GameException;
public interface Gamedao {
	public boolean save(Game game)  ;
	public List<Game> findByName(String name) throws GameException;
	public List<Game> findAll();
}
