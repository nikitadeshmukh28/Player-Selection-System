package com.cg.playerselectiondb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.playerselctiondb.dto.Game;
import com.cg.playerselctiondb.dto.Player;
import com.cg.playerselctiondb.service.PlayerServiceImpl;
import com.cg.playerselectiondb.exception.GameException;
import com.cg.playerselectiondb.util.DButil;

public class gameDaoImpl implements Gamedao {
	static PlayerServiceImpl serviceone;

	public boolean save(Game game) { // This method is used to add a game.
		Connection con = null;
		con = DButil.getConnection();
		String query1 = "INSERT INTO game VALUE(?,?) ";
		String query2 = "update player set player.g_gameId=? where player.playerskill=?";
		PreparedStatement pst = null;
		PreparedStatement pstm = null;
		try {
			pst = con.prepareStatement(query1);
			pstm = con.prepareStatement(query2);
			pst.setInt(1, game.getGameId());
			pst.setString(2, game.getName());
			pstm.setInt(1, game.getGameId());
			pstm.setString(2, game.getName());
			pst.executeUpdate();
			pstm.executeUpdate();
		} catch (SQLException e) {
			throw new GameException("game already exist");
		} finally {
			try {
				pst.close();
				pstm.close();
				con.close();
			} catch (SQLException e) {

			}

		}
		return true;
	}

	public List<Game> findByName(String name) throws GameException {
		Connection con = DButil.getConnection();
		String query_show = "select * from game where gamename=?";
		PreparedStatement pstm = null;
		List<Game> mylist = new ArrayList<Game>();
		try {
			pstm = con.prepareStatement(query_show);
			pstm.setString(1, name);
			ResultSet result = pstm.executeQuery();

			while (result.next()) {
				Game game = new Game();
				game.setGameId(result.getInt("gameId"));
				game.setName(result.getString("gameName"));
				mylist.add(game);
			}
		} catch (SQLException e) {
			throw new GameException("Game not Found");
		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {

			}
		}
		if (mylist.isEmpty()) {
			throw new GameException("Game not Found");
		}
		return mylist;
	}

	public List<Game> findAll() {
		Connection con = DButil.getConnection();
		String query_show = "select gameId,gamename from Game";
		PreparedStatement pstm = null;
		List<Game> mylist = new ArrayList<Game>();
		try {
			pstm = con.prepareStatement(query_show);

			ResultSet result = pstm.executeQuery();

			while (result.next()) {
				Game g = new Game();
				g.setGameId(result.getInt("gameId"));
				g.setName(result.getString("gamename"));

				mylist.add(g);
			}
		} catch (SQLException e) {

		} finally {
			try {
				pstm.close();
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block

			}
		}
		return mylist;
	}

}
