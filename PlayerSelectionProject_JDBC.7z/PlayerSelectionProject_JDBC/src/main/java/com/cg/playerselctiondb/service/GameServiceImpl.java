package com.cg.playerselctiondb.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.playerselctiondb.dto.Game;
import com.cg.playerselectiondb.dao.Gamedao;
import com.cg.playerselectiondb.dao.gameDaoImpl;
import com.cg.playerselectiondb.exception.GameException;

public class GameServiceImpl implements GameService {
	Gamedao dao;

	public GameServiceImpl() {
		super();
		dao = new gameDaoImpl();
	}

	public Game addGame(Game game) {
		// TODO Auto-generated method stub
		dao.save(game);
		return game;
	}

	public List<Game> searchByName(String name) throws GameException {
		// TODO Auto-generated method stub
		return dao.findByName(name);
	}

	public List<Game> showAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
