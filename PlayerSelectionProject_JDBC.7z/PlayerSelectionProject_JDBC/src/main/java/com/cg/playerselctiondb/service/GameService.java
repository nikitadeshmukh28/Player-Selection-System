package com.cg.playerselctiondb.service;
import java.sql.SQLException;
import java.util.List;

import com.cg.playerselctiondb.dto.Game;
import com.cg.playerselectiondb.exception.GameException;

public interface GameService {
	public Game addGame(Game game) ;
	public List<Game> searchByName(String name) throws GameException;
	public List<Game>  showAll();}

