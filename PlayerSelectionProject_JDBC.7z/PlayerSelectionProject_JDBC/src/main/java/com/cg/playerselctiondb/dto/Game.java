package com.cg.playerselctiondb.dto;
import java.util.List;

public class Game {
	private int gameId;
	public int getGameId() {
		return gameId;
	}
	public void setGameId(int gameId) {
		this.gameId = gameId;
	}
	private String name;
	private List<Player> player;

	@Override
	public String toString() {
		return "Game [gameId=" + gameId + ", name=" + name + ", player=" + player + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Player> getPlayer() {
		return player;
	}
	public void setPlayer(List<Player> player) {
		this.player = player;
	}
	
	public Game(int gameId, String name, List<Player> player) {
		super();
		this.gameId = gameId;
		this.name = name;
		this.player = player;
	}
	public Game() {
		super();
	}
	public Game(String name) {
		super();
		this.name = name;
	}


}
