package com.cg.playerselctiondb.service;
import java.sql.SQLException;
import java.util.List;

import com.cg.playerselctiondb.dto.Player;
import com.cg.playerselectiondb.exception.GameException;
import com.cg.playerselectiondb.exception.PlayerException;
public interface PlayerService {
	public Player addPlayer(Player p) throws SQLException, PlayerException ;
	public Player searchById(int playerId) throws PlayerException;
	public List<Player> searchBySkill(String skill) throws PlayerException;
   public List<Player> showAll();	
}
