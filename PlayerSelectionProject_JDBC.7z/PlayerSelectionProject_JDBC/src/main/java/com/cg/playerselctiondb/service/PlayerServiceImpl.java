package com.cg.playerselctiondb.service;

import java.sql.SQLException;
import java.util.List;

import com.cg.playerselctiondb.dto.Player;
import com.cg.playerselectiondb.dao.Playerdao;
import com.cg.playerselectiondb.dao.playerdaoImpl;
import com.cg.playerselectiondb.exception.GameException;
import com.cg.playerselectiondb.exception.PlayerException;

public class PlayerServiceImpl implements PlayerService{
	Playerdao dao;
	public PlayerServiceImpl() {
		super();
		dao = new playerdaoImpl();}
	public Player addPlayer(Player p) throws SQLException, PlayerException {
		dao.save(p);
		return p;}
	public Player searchById(int playerId) throws PlayerException {
		// TODO Auto-generated method stub
		Player pa=dao.findById(playerId);
		return pa;
	}

	public List<Player> searchBySkill(String skill) throws PlayerException {
		// TODO Auto-generated method stub
		return dao.findbyskill(skill);
	}

	public List<Player> showAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}
	
}
