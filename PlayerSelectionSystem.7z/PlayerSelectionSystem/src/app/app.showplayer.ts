import{Component,OnInit} from '@angular/core';
import {PlayerService} from './app.playerservice';
import {Player} from './app.player';


@Component({
    selector:'show-play',
    templateUrl:'showplayer.html'
})
export class ShowPlayer implements OnInit{

players:Player;
model:any={};
constructor(private playservice:PlayerService){
    console.log("In Player Constructor");
}
ngOnInit(){
    this.playservice.getAllPlayer().subscribe((data:Player)=>this.players=data);
}
}