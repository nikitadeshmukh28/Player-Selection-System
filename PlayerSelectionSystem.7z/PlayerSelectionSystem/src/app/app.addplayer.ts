
import {PlayerService} from './app.playerservice';
import {Player} from './app.player';
import {Component} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
    selector:'add-play',
    templateUrl:'addplayer.html'
})
export class AddPlayer{
PlayerProfile= new FormGroup({
   Id: new FormControl(''),
    name: new FormControl(''),
    skill: new FormControl(''),
    gameId: new FormControl('')

});


    players:Player[];
  model:any={};
 
 
constructor(private playservice:PlayerService){
    console.log("In Player Constructor");

  
}

addPlayer(){
  
  this.playservice.addPlayer(this.model).subscribe((data:any)=>console.log(data));
}

}