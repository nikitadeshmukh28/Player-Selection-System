import {Game} from './app.game';
export class Player{
    playerId:number;
    name:string;
    skill:string;
    gameId:Game;
}