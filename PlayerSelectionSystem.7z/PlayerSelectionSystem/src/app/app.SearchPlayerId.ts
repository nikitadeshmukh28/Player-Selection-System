import{Component,OnInit} from '@angular/core';
import {PlayerService} from './app.playerservice';
import {Player} from './app.player';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
    selector:'search-playerId',
    templateUrl:'searchPlayerId.html'
})
export class SearchPlayerId implements OnInit{
PlayerSearch= new FormGroup({
   id: new FormControl(''),
})


constructor(private playservice:PlayerService){
    console.log("In Player Constructor");
}
players:Player;
model:any={};
ngOnInit(){}
searchplayerById(){
console.log(this.playservice.searchplayerById(this.model).subscribe((data:any)=>this.players=data));
}
}




