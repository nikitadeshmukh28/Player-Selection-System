
import {PlayerService} from './app.playerservice';
import {Game} from './app.game';
import {Component} from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
@Component({
    selector:'add-gameone',
    templateUrl:'addgame.html'
})
export class AddGame{
GameProfile= new FormGroup({
   Id: new FormControl(''),
    name: new FormControl(''),
});
    games:Game[];
model:any={};
constructor(private playservice:PlayerService){
    console.log("In Player Constructor");
}

addGame(){
  
  this.playservice.addGame(this.model).subscribe((data:any)=>console.log(data));
}

}