import{Player} from './app.player'
export class Game{
    gameId:number;
    name:string;
    myplayerlist:Player[];
}