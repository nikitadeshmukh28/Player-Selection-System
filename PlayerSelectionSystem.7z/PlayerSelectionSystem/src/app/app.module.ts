﻿import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import{AddPlayer} from './app.addplayer';
import {ShowPlayer} from './app.showplayer';
import {SearchGame} from './app.searchgamename';
import {HttpClientModule} from '@angular/common/http';
import {FormsModule,ReactiveFormsModule} from '@angular/forms'; 
import {Routes,RouterModule} from '@angular/router';
import{AddGame} from './app.addgame';
import {ShowGame} from './app.showgame';
import {SearchPlayerId} from './app.SearchPlayerId';
import {SearchPskill} from './app.searchpskill';
const route:Routes=[
    {path:"addplayer",component:AddPlayer},
     {path:"addgame",component:AddGame},
     {path:"showplayer",component:ShowPlayer},
     {path:"showgame",component:ShowGame},
    {path:"searchgamename",component:SearchGame},
    {path:"searchpskill",component:SearchPskill},
    {path:"searchplayerId",component:SearchPlayerId}
];


@NgModule({
    imports: [
        BrowserModule,HttpClientModule,FormsModule,RouterModule.forRoot(route),ReactiveFormsModule
        
    ],
    declarations: [
        AppComponent,AddPlayer,AddGame,ShowPlayer,ShowGame,SearchGame,SearchPskill,SearchPlayerId
		],
    providers: [ ],
    bootstrap: [AppComponent]
})

export class AppModule { }