import{Component,OnInit} from '@angular/core';
import {PlayerService} from './app.playerservice';
import {Game} from './app.game';


@Component({
    selector:'show-gameone',
    templateUrl:'showgame.html'
})
export class ShowGame implements OnInit{

games:Game[];
model:any={};
constructor(private playservice:PlayerService){
    console.log("In Player Constructor");
}
ngOnInit(){
    this.playservice.getAllGame().subscribe((data:Game[])=>this.games=data);
}
}