import{Component,OnInit} from '@angular/core';
import {PlayerService} from './app.playerservice';
import {Game} from './app.game';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
    selector:'search-gameone',
    templateUrl:'searchgamename.html'
})
export class SearchGame implements OnInit{
GameSearch= new FormGroup({
   name: new FormControl(''),
})
constructor(private playservice:PlayerService){
    console.log("In Player Constructor");
}
games:Game;
model:any={};
ngOnInit(){}
searchgameByName(){
  console.log(this.playservice.searchgameByName(this.model).subscribe((data:any)=>this.games=data));
}
}