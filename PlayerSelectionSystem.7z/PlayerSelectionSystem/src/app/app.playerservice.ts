
 import {Injectable} from '@angular/core';
 import {HttpClient,HttpParams} from '@angular/common/http';
 import {Player} from './app.player';
 import { Observable, throwError } from 'rxjs';
import { retry, catchError } from 'rxjs/operators';

 @Injectable({
    providedIn:'root'
})
 export class PlayerService{

constructor(private  http:HttpClient){}


getAllPlayer(){

    return this.http.get("http://localhost:9080/player/showplayer") .pipe(
        retry(1),
        catchError(this.handleError)
      );
}

addPlayer(play:any){

    console.log(play);
    let input=new FormData();
    input.append("playerId",play.playerId);
    input.append("name",play.name);
    input.append("skill",play.skill);
    input.append("gameId",play.gameId);


    return this.http.post("http://localhost:9080/player/addplayer",input) .pipe(
        retry(1),
        catchError(this.handleError)
      );
}

addGame(gameone:any){
    console.log(gameone);
    let inputone=new FormData();
    inputone.append("gameId",gameone.gameId);
    inputone.append("name",gameone.name);

    return this.http.post("http://localhost:9080/player/addgame",inputone) .pipe(
        retry(1),
        catchError(this.handleError)
      );
}

getAllGame(){

    return this.http.get("http://localhost:9080/player/showgames") .pipe(
        retry(1),
        catchError(this.handleError)
      );

    
}
searchgameByName(games:any){
    let input=new FormData();
    input.append("name",games.name);
return this.http.post("http://localhost:9080/player/searchgname",input) .pipe(
        retry(1),
        catchError(this.handleError)
      );
}

searchplayerById(players:any){
    let input=new FormData();
    input.append("playerId",players.playerId);
return this.http.post<any>("http://localhost:9080/player/searchplayerId",input) .pipe(
        retry(1),
        catchError(this.handleError)
      );
 }


 searchplayerBySkill(players:any){
let input=new FormData();
    input.append("skill",players.skill);
 return this.http.post<any>("http://localhost:9080/player/searchpskill",input) .pipe(
        retry(1),
        catchError(this.handleError)
      );
 }

handleError(error) {
    let errorMessage = '';
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error}`;
    } else {
      errorMessage =  `${error.error}`;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }


 }




