package com.cg.playerselectionbyspring.service;

import java.util.List;

import com.cg.playerselectionbyspring.dto.Game;
import com.cg.playerselectionbyspring.exceptions.GameException;
import com.cg.playerselectionbyspring.exceptions.PlayerException;
import com.cg.playerselectionbyspring.exceptions.PlayerException;

public interface GameService {
	public Game addGame(Game game);

	public List<Game> searchByName(String name) throws GameException;

	public List<Game> showAll();
}
