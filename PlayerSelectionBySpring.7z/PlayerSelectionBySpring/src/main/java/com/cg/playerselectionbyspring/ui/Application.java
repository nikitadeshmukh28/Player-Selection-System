package com.cg.playerselectionbyspring.ui;
/** 
 * This is the main method which makes use of all the functionalities in the project.
 
 * 
 */ 
/** 
 */
import java.util.List;
import java.util.Scanner;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.playerselectionbyspring.config.JavaConfig;
import com.cg.playerselectionbyspring.dto.Game;
import com.cg.playerselectionbyspring.dto.Player;
import com.cg.playerselectionbyspring.service.GameService;
import com.cg.playerselectionbyspring.service.PlayerService;

@Component
public class Application {
	@Autowired
	PlayerService service;
	@Autowired
	GameService serviceone;
	static PlayerService playerService;
	static GameService gameService;

	@PostConstruct
	private void init() {
		playerService = this.service;

	}

	@PostConstruct
	private void initone() {
		gameService = this.serviceone;

	}

	public static void main(String args[]) {
		ApplicationContext ctx = new AnnotationConfigApplicationContext(JavaConfig.class);
		Scanner scr = new Scanner(System.in);
		// serviceone=(GameService) ctx.getBean("GameService");

		int choice = 0;
		do {
			printDetails();
			System.out.println("Enter your choice");
			System.out.println("*****************************************************");
			choice = scr.nextInt();
			switch (choice) {

			case 1:
				System.out.println("Enter Game Name");
				String name = scr.next();
				Game gameso = (Game) ctx.getBean("game");
				gameso.setName(name);
				System.out.println(gameService.addGame(gameso).getName());
				System.out.println("The list of players");
				try {
					List<Player> players = playerService.searchBySkill(name);
					for (Player playerAll : players) {
						System.out.println(playerAll);
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				break;

			case 2:
				List<Game> mylist = gameService.showAll();
				for (Game gameData : mylist) {
					System.out.println(gameData.getName());
					System.out.println("The list of players");
					try {
						List<Player> players = playerService.searchBySkill(gameData.getName());
						for (Player playerAll : players) {
							System.out.println(playerAll);
						}
					} catch (Exception e) {
						System.out.println(e.getMessage());
					}
					System.out.println("\n");
				}

				break;

			case 3:
				System.out.println("Enter the Game to search by Name");
				String gname = scr.next();
				try {
					List<Game> games = gameService.searchByName(gname);
					
					for (Game gameAll : games) {
						System.out.println("Name is " + gameAll.getName());
					}
					List<Player> players = playerService.searchBySkill(gname);
					System.out.println("   the players matches for the game are");
					for (Player playerAll : players) {
						System.out.println(playerAll.getName());
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				break;

			case 4:
				System.out.println("Enter Player Name");
				String pname = scr.next();
				System.out.println("Enter Player Id");
				int playerId = scr.nextInt();
				System.out.println("Enter Player Skill");
				String skill = scr.next();
				Player myplayer = (Player) ctx.getBean("p");
				myplayer.setName(pname);
				myplayer.setPlayerId(playerId);
				myplayer.setSkill(skill);
				playerService.addPlayer(myplayer);
				System.out.println(myplayer);
				break;

			case 5:
				System.out.println("enter any game name as skill whose player you want:");
				String skill1 = scr.next();
				try {
					List<Player> players = playerService.searchBySkill(skill1);
					System.out.println("The players with this skill are" + players);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				break;
			case 6:
				System.out.println("Enter the player id to search");
				int sid = scr.nextInt();
				try {
					Player prosearch = playerService.searchById(sid);
					if (prosearch != null) {

						System.out.println(prosearch);
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}
				break;
			case 7:
				System.out.println("Thanks for Using this Application");
			}
		} while (choice != 8);

	}

	private static void printDetails() {
		System.out.println("1.add game");
		System.out.println("2.Show All Game");
		System.out.println("3.Search game by Name");
		System.out.println("4.Add Player");
		System.out.println("5.Search player by skill");
		System.out.println("6.Search Player By Id");
		System.out.println("7.Exit");
	}
}
