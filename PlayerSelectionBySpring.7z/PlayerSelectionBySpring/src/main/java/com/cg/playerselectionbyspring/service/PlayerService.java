package com.cg.playerselectionbyspring.service;

import java.util.List;

import com.cg.playerselectionbyspring.dto.Player;
import com.cg.playerselectionbyspring.exceptions.PlayerException;

public interface PlayerService {
	public Player addPlayer(Player p);

	public Player searchById(int playerId) throws PlayerException;

	public List<Player> searchBySkill(String skill) throws PlayerException;
}