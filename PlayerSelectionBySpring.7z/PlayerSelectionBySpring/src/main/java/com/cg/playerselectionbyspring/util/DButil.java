package com.cg.playerselectionbyspring.util;

import java.util.ArrayList;
import java.util.List;

import com.cg.playerselectionbyspring.dto.Game;

public class DButil{
	private DButil() {}
	public static List<Game> games=new ArrayList<Game>();}