package com.cg.playerselectionbyspring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import com.cg.playerselectionbyspring.dto.Game;
import com.cg.playerselectionbyspring.exceptions.GameException;
import com.cg.playerselectionbyspring.util.DButil;
/**
/*
* This is the Repository class which makes connectivity with database in the project.
* @Author Nikita Deshmukh
*/ 
/**
 * 
 */
@Repository("gamedao")
public class GameDaoImpl implements GameDao {
	/**
	 * This is the saveGame method which adds the games in the list.
	 * @param here object of game is passed as an argument
	 * @return object of Game.
	 */ 

	public boolean save(Game game) {
		// TODO Auto-generated method stub
		DButil.games.add(game);
		return true;
	}

	/**
	 * This is the findGame method which finds the games in the list.
	 * @param here name of game is passed as an argument
	 * @return List of Game.
	 */ 
	public List<Game> findByName(String name) {
		List<Game> gamesearch = new ArrayList<Game>();
		for (Game game : DButil.games) {
			if (game.getName().equals(name)) {
				gamesearch.add(game);
			}
		}
		
		/**
		 * if game is not found method will throw exception.
		 *
		 * 
		 */ 
		if (gamesearch.isEmpty()) {
			throw new GameException("Game not Found");
		}
		return gamesearch;
	}
	/**
	 * This is the findGame method which finds the games in the list.
	 * @param here no parameter passed as an argument
	 * @return List of Game.
	 */ 

	public List<Game> findAll() {
		// TODO Auto-generated method stub
		return DButil.games;
	}

}
