package com.cg.playerselectionbyspring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.playerselectionbyspring.dao.GameDao;
import com.cg.playerselectionbyspring.dao.GameDaoImpl;
import com.cg.playerselectionbyspring.dto.Game;
import com.cg.playerselectionbyspring.exceptions.GameException;
/**
/*
* This is the Service class which implements GameService Interface.
* @Author Nikita Deshmukh
*/ 
/**
 * 
 */
@Service("GameService")
public class GameServiceImpl implements GameService {
	/**
	 * Autowried annotation is for getting the bean of Gamedao from spring application content 
	 * and wiring it as a dependency for GameService object
	 */
	@Autowired
	GameDao dao;

	public GameServiceImpl() {
		super();
	}

	public Game addGame(Game game) {
		// TODO Auto-generated method stub
		dao.save(game);
		return game;
	}

	public List<Game> searchByName(String name) throws GameException {
		// TODO Auto-generated method stub
		return dao.findByName(name);
	}

	public List<Game> showAll() {
		// TODO Auto-generated method stub
		return dao.findAll();
	}

}
