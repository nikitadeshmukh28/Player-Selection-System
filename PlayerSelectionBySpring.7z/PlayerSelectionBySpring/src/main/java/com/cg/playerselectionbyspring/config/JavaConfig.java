package com.cg.playerselectionbyspring.config;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import com.cg.playerselectionbyspring.service.GameService;
import com.cg.playerselectionbyspring.service.PlayerService;
/**
 * @Configuration Indicates that a class declares one or more @Bean methods and processed by the Spring container
 *  to generate bean definitions and service requests for beans at runtime
 * @author nikitade
 *
 */
@Configuration

/**
 * Scanning will occur for whole package which is declared below for beans.
 * @author nikitade
 *
 */
@ComponentScan("com.cg.playerselectionbyspring")

public class JavaConfig {

	PlayerService playerService;
	GameService GameService;

}