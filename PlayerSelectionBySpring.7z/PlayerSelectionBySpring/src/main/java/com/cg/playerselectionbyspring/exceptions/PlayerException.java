package com.cg.playerselectionbyspring.exceptions;

public class PlayerException extends RuntimeException{
	public PlayerException() {
		super();
	}
	public PlayerException(String msg) {
		super(msg);
	}
}