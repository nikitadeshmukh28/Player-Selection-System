package com.cg.playerselectionbyspring.dao;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.cg.playerselectionbyspring.dto.Player;
import com.cg.playerselectionbyspring.exceptions.PlayerException;
import com.cg.playerselectionbyspring.util.DButilPlayer;
/**
/*
* This is the Repository class which makes connectivity with database in the project.
* @Author Nikita Deshmukh
*/ 
/**
 * 
 */
@Repository("playerdao")
public class PlayerDaoImpl implements PlayerDao {
	/**
	 * This is the saveplayer method which adds the players in the list.
	 * @param here object of game is passed as an argument
	 * @return object of Player.
	 */ 

	public boolean save(Player p) {
		// TODO Auto-generated method stub
		DButilPlayer.playerlist.add(p);
		return true;
	}

	/**
	 * This is the findbyskill method which finds the players in the list.
	 * @param here skill is passed as an argument
	 * @return List of Player.
	 */ 
	public List<Player> findbyskill(String skill) {
		List<Player> playersearch = new ArrayList<Player>();
		for (Player p :DButilPlayer.playerlist) {
			if (p.getSkill().equals(skill)) {
				playersearch.add(p);
			}
		}
		/**
		 * if player is not found method will throw exception.
		 *
		 * 
		 */ 
		if (playersearch.isEmpty()) {
			throw new PlayerException("Player not found for this skill");
		}
		return playersearch;
	}

	/**
	 * This is the findbyid method which finds the player from the list.
	 * @param here id is passed as an argument
	 * @return Player with that id.
	 */ 
	public Player findById(int playerId) {
		for (Player ps : DButilPlayer.playerlist)
			if (ps.getPlayerId() == (playerId))
				return ps;
		throw new PlayerException("Id not Found");
	}

}
