package com.cg.playerselectionbyspring.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.playerselectionbyspring.dao.PlayerDao;
import com.cg.playerselectionbyspring.dao.PlayerDaoImpl;
import com.cg.playerselectionbyspring.dto.Player;
import com.cg.playerselectionbyspring.exceptions.PlayerException;
/**
/*
* This is the Service class which implements Player Service Interface.
* @Author Nikita Deshmukh
*/ 
/**
 * 
 */
@Service("PlayerService")

public class PlayerServiceImpl implements PlayerService {
	/**
	 * Autowried annotation is for getting the bean of Playerdao from spring application content 
	 * and wiring it as a dependency for PlayerService object
	 */
	@Autowired
	PlayerDao dao;

	public PlayerServiceImpl() {
	}

	public Player addPlayer(Player p) {
		// TODO Auto-generated method stub
		dao.save(p);
		return p;
	}

	public Player searchById(int playerId) throws PlayerException {
		// TODO Auto-generated method stub
		return dao.findById(playerId);
	}

	public List<Player> searchBySkill(String skill) throws PlayerException {
		// TODO Auto-generated method stub
		return dao.findbyskill(skill);
	}

}
