package com.cg.playerselectionbyspring.exceptions;

public class GameException extends RuntimeException {
	public GameException() {
		super();
	}

	public GameException(String msg) {
		super(msg);
	}
}
