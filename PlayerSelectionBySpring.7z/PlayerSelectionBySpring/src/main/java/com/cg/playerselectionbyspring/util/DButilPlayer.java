package com.cg.playerselectionbyspring.util;
import com.cg.playerselectionbyspring.dto.Game;
import com.cg.playerselectionbyspring.dto.Player;

import java.util.ArrayList;
import java.util.List;
public class DButilPlayer {
	public static List<Player> playerlist=new ArrayList<Player>();
	
		}
