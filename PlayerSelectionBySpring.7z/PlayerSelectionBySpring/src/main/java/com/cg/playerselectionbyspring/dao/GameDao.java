package com.cg.playerselectionbyspring.dao;

import java.util.List;

import com.cg.playerselectionbyspring.dto.Game;
import com.cg.playerselectionbyspring.exceptions.GameException;

public interface GameDao {
	public boolean save(Game game);

	public List<Game> findByName(String name) throws GameException;

	public List<Game> findAll();
}
