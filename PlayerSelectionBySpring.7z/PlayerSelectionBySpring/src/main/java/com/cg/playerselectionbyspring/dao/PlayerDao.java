package com.cg.playerselectionbyspring.dao;

import java.util.List;

import com.cg.playerselectionbyspring.dto.Player;
import com.cg.playerselectionbyspring.exceptions.PlayerException;

public interface PlayerDao {
	public boolean save(Player p);

	public List<Player> findbyskill(String skill) throws PlayerException;

	public Player findById(int playerId) throws PlayerException;

}