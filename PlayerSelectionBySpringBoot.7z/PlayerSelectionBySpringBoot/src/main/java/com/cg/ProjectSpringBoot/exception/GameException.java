package com.cg.ProjectSpringBoot.exception;
/**
 *  * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 * This is the Exception Class which is used to print the exception message from Game.
 * 
 *
 */
public class GameException extends RuntimeException {
	public GameException() {
		super();
	}

	public GameException(String msg) {
		super(msg);
	}
}

