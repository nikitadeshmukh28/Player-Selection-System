package com.cg.ProjectSpringBoot.service;

import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProjectSpringBoot.dao.PlayerDao;
import com.cg.ProjectSpringBoot.dto.Player;
import com.cg.ProjectSpringBoot.exception.PlayerException;

/**
 *  * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 * @Service Indicates that a class declares as a Service and also it consider as a bean.
 * @Autowired annotation injects gamedao properties in this class
 *
 *
 */
@Service
public class PlayerServiceImpl implements PlayerService {
	static final Logger logger = Logger.getLogger(PlayerServiceImpl.class); 	 
	@Autowired
	PlayerDao playerdao;
	
	
	/**
	 * This is the addplayer method which add the player in database.
	 * @Exception when we want to add the same player in database having same Id it will through Exception.
	 * @param here object of player is passed as argument.
	 * @return player object if player added.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public Player addPlayer(Player p) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		Player ps=playerdao.findByPlayerId(p.getPlayerId());
		if(ps==null) {
		playerdao.save(p);}
		else {
			logger.warn("add player method throws exception for duplicate id"); 
			throw new PlayerException("Player id Already Exist,try with another id");
		}
		logger.info("Player added successful"); 
		return p;
	}

	
	/**
	 * This is the searchbyId method which searches the player whose Id is match with given Id.
	 * @Exception when we want to retrieve the player  which is not yet saved with that id it throws the exception Player is not found with this Id.
	 * @param here playerId is passed as argument.
	 * @return object of player.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public Player searchById(int playerId) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		Player p=playerdao.findByPlayerId(playerId);
		if(p==null) {
			logger.warn("player with that id is not found"); 
			throw new PlayerException("Player For This id is Not Found");
		}
		logger.info("Player search method executed successfully"); 
		return p;
	}

	
	/**
	 * This is the searchbySkill method which searches the players whose skill are match with given skill.
	 * @Exception when we want to retrieve the player  which is not yet saved it throws the exception Game With this skill is not found.
	 * @param here skill is passed as argument.
	 * @return List of player.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public List<Player> searchBySkill(String skill) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		List<Player> ps=playerdao.findBySkill(skill);
		if(ps.isEmpty()) {
			logger.warn("players with that skill are not found"); 
			throw new PlayerException("Player For This Skill is Not Found");
		}
		logger.info("Player searchBySkill method executed successfully"); 
		return ps;
	}

	
	/**
	 * This is the showAllPlayer  method which searches the All players .
	 * @param here no argument is passed.
	 * @return List of player.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public List<Player> show() {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		List<Player> ps=playerdao.findAll();
		if(ps.isEmpty()) {
			logger.warn("players not found for display"); 
			throw new PlayerException("Player is not present to show");
		}
		logger.info("Players show All method executed successfully"); 
		return playerdao.findAll();
	}
	
	
	
}
