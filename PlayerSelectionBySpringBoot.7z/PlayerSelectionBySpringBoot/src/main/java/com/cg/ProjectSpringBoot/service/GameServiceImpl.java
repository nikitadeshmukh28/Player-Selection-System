package com.cg.ProjectSpringBoot.service;

import java.util.List;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ProjectSpringBoot.dao.GameDao;
import com.cg.ProjectSpringBoot.dto.Game;
import com.cg.ProjectSpringBoot.exception.GameException;
/**
 *  * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 * @Service Indicates that a class declares as a Service and also it consider as a bean.
 * @Autowired annotation injects gamedao properties in this class
 * 
 *
 */

@Service
public class GameServiceImpl implements GameService{
	static final Logger logger = Logger.getLogger(GameServiceImpl.class); 
	@Autowired
    GameDao gamedao;
	@Override
	 /**
	 * This is the savegame method which add the game in database.
	 * @Exception when we want to add the same game in database having same Id it will through Exception.
	 * @param here object of game is passed as argument.
	 * @return game object if game added.
	 * @author nikitade
	 */ 
	public Game save(Game game) {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
	Game gm=gamedao.findByGameId(game.getGameId());
	if(gm==null) {
		gamedao.save(game);
	}
	else {
		logger.warn("add Game method throws exception for duplicate id"); 
	throw new GameException("Game Id Already Exist,Please try with Another Id");}
	logger.info("Game added successful"); 
	return game;
	
	}

	/**
	 * This is the searchbyName method which searches the games whose names are match with given name.
	 * @Exception when we want to retrieve the game  which is not yet saved it throws the exception Game With this name is not found.
	 * @param here name of game is passed as argument.
	 * @return the object of game.
	 * @author nikitadeshmukh
	 */ 
	@Override
	public Game findByName(String name) throws GameException{
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		// TODO Auto-generated method stub
		Game gsg=gamedao.findByName(name);
		if(gsg==null) {
			logger.warn("Game with this name is not found");
			throw new GameException("Game with this name is not found");
		}
		logger.info("Game searchbyName method executed successfully"); 
		return gsg;
		
	}

	
	/**
	 * This is the findAll method which searches the All games .
	 * @param here no argument is passed.
	 * @return List of game.
	 * @author nikitade
	 */ 
	@Override
	public List<Game> showAll() {
		PropertyConfigurator.configure("D:\\Users\\PlayerSelectionBySpringBoot\\src\\main\\resources\\log4j.properties");
		List<Game> ps=gamedao.findAll();
		if(ps.isEmpty()) {
			logger.warn("games not found for display"); 
			throw new GameException("Game is not present to show");
			
		}
		logger.info("games show All method executed successfully"); 
		return gamedao.findAll();
	}

	@Override
	public Game findByGameId(int id) throws GameException {
		// TODO Auto-generated method stub
		Game g=gamedao.findByGameId(id);
		if(g==null) {
			logger.warn("Game with this name is not found");
			throw new GameException("Game with this id is not found");
		}
		logger.info("Game searchbyid method executed successfully"); 
		return g;
	}
	
}
