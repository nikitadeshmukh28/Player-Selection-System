package com.cg.ProjectSpringBoot.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
/**
 *  * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 * @Entity Indicates that a class declares as a Entity.
 * @Table Annotation is used for creating table as name Player. 
 * 
 * 
 *
 */

@Entity
@Table(name="player")
public class Player {
	//@Id is used for creating primary key .
	@Id
	//create column with given name.
	@Column(name="player_id")
	//declare the variable.
	private int playerId;
	//create column with name.
	@Column(name="player_skill")
	private String skill;
	@Column(name="player_name")
	private String name;
	@Column(name="gameId")
	private int gameId;

	//@JoinColumn is used to create one joinColumn instead of creating the third table.
		//declare the list of players.
	public Player() {
		super();
	}
	
	

	//These are getters and setters for player variables.
	
	
	

	public int getGameId() {
		return gameId;
	}



	public void setGameId(int gameId) {
		this.gameId = gameId;
	}


	//This is parameterized constructor.
	public Player(int playerId, String skill, String name, int gameId) {
		super();
		this.playerId = playerId;
		this.skill = skill;
		this.name = name;
		this.gameId = gameId;
	}



	//this used for get the player name.
	public String getName() {
		return name;
	}
	//this is used for set the player name.
	public void setName(String name) {
		this.name = name;
	}
	//this used for get the player Id.
	public int getPlayerId() {
		return playerId;
	}
	//this is used for set the player Id.
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}
	//this used for get the player skill.
	public String getSkill() {
		return skill;
	}
	//this is used for set the player skill.
	public void setSkill(String skill) {
		this.skill = skill;
	}
	//this is used for displaying the player object.



	@Override
	public String toString() {
		return "Player [playerId=" + playerId + ", skill=" + skill + ", name=" + name + ", gameId=" + gameId + "]";
	}

	
	

}
