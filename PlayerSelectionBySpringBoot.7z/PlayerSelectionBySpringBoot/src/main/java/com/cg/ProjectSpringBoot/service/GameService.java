package com.cg.ProjectSpringBoot.service;

import java.util.List;

import com.cg.ProjectSpringBoot.dto.Game;
import com.cg.ProjectSpringBoot.exception.GameException;

public interface GameService {
   
	public Game save(Game game) throws GameException;
	public Game findByName(String name) throws GameException;
	public List<Game> showAll();
	public Game findByGameId(int id) throws GameException;
	
}
