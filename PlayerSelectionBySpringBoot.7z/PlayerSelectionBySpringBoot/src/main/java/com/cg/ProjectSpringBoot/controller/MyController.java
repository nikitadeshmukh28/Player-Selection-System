package com.cg.ProjectSpringBoot.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.cg.ProjectSpringBoot.dto.Game;
import com.cg.ProjectSpringBoot.dto.Player;
import com.cg.ProjectSpringBoot.exception.GameException;
import com.cg.ProjectSpringBoot.exception.PlayerException;
import com.cg.ProjectSpringBoot.service.GameService;
import com.cg.ProjectSpringBoot.service.PlayerService;
/**
 * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 *  by using @RestController annotation  it will provides the restful web services.
 */

@RestController
/**
 * @RequestMapping Annotation is used  for mapping web requests onto methods.
 * By using this request mapping it will come to this controller.
 */
@RequestMapping("/player")

public class MyController {
	/**
	 * @Autowired is used to inject properties of PlayerService.
	 */
	@Autowired
	PlayerService playerservice;
	/**
	 * @Autowired is used to inject properties of GameService.
	 */
	@Autowired
	GameService gameservice;
	 /**
	   * this method will executed after request come for /addgame.
	   *  @return the object/entity of game.
	   */
	@RequestMapping(value = "/addgame", method = RequestMethod.POST)
	public ResponseEntity<Game> addGame(@RequestBody Game gm) {
		System.out.println(gm);
		Game gms=gameservice.save(gm);
		
		
		return new ResponseEntity<Game>(gms,HttpStatus.OK);
	}
	
	
	
	 /**
	   * this method will executed after request come for /addplayer.
	   *  @return the object/entity of player.
	   */
	@RequestMapping(value = "/addplayer", method = RequestMethod.POST)
 public ResponseEntity<Player> addAll(@RequestBody Player pl){
Player pls=playerservice.addPlayer(pl);
 Game g=gameservice.findByGameId(pls.getGameId());
	 List<Player> plist=g.getMyplayerlist();
	 plist.add(pls);
	 g.setMyplayerlist(plist);
		return new ResponseEntity<Player>(pls,HttpStatus.OK);
	}
	 
    
	
	
	 /**
	   * this method will executed after request come for /searchplayerId.
	   *  @return the object/entity of player with given id.
	   */
	@RequestMapping(value = "/searchplayerId", method = RequestMethod.POST)
	public ResponseEntity<Player> searchPlayer(@RequestParam ("id") int id) {
		Player p=playerservice.searchById(id);
		
		return new ResponseEntity<Player>(p,HttpStatus.OK);

	}

	
	 /**
	   * this method will executed after request come for /searchpskill.
	   *  @return the list of player with given skill.
	   */
	@RequestMapping(value = "/searchpskill", method = RequestMethod.POST)
	public ResponseEntity<List<Player>> searchskill(@RequestParam ("skill") String skill) {
		List<Player> myList = playerservice.searchBySkill(skill);
	
		
		return new ResponseEntity<List<Player>>(myList,HttpStatus.OK);

	}
	
	
	
	 /**
	   * this method will executed after request come for /searchgname.
	   *  @return the Game with this name.
	   */
	@RequestMapping(value = "/searchgname", method = RequestMethod.POST)
	public ResponseEntity<Game> searchgame(@RequestParam ("gamename") String gamename) {
		Game gm=gameservice.findByName(gamename); 
		
		return new ResponseEntity<Game>(gm,HttpStatus.OK);

	}
	
	

	 /**
	   * this method will executed after request come for /showplayer.
	   *  @return all the players.
	   */
	@RequestMapping(value = "/showplayer", method = RequestMethod.GET)
	public ResponseEntity<List<Player>> showAllPlayer() {
		List<Player> myList = playerservice.show();
		
		
		return new ResponseEntity<List<Player>>(myList,HttpStatus.OK);

	}
	
	
	 /**
	   * this method will executed after request come for /showgames.
	   *  @return all the games.
	   */
	
	@RequestMapping(value = "/showgames", method = RequestMethod.GET)
	public ResponseEntity<List<Game>> showAllGame() {
		List<Game> myList = gameservice.showAll();
	
		
		return new ResponseEntity<List<Game>>(myList,HttpStatus.OK);

	}
	
	
	/**
	  * @ExceptionHandler Annotation used for handling Game exceptions which are thrown from this controller class.
	  * 
	  * @return the Exception message.
	  */
	
		@ExceptionHandler({GameException.class})
			public ResponseEntity<String> handleGameException(GameException error) {
				return  new ResponseEntity<String>(error.getMessage(),HttpStatus.NOT_FOUND);

			}  
		 
		 
		/**
		  * @ExceptionHandler Annotation used for handling Player exceptions which are thrown from this controller class.
		  * 
		  * @return the Exception message.
		  */
		

		@ExceptionHandler({PlayerException.class})
		public ResponseEntity<String> handlePlayerException(PlayerException error) {
			return  new ResponseEntity<String>(error.getMessage(),HttpStatus.NOT_FOUND);

		}  
	
}
