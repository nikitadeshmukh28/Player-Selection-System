package com.cg.ProjectSpringBoot.service;

import java.util.List;

import com.cg.ProjectSpringBoot.dto.Player;
import com.cg.ProjectSpringBoot.exception.PlayerException;



public interface PlayerService {

	public Player addPlayer(Player p) throws PlayerException;

	public Player searchById(int playerId) throws PlayerException;
	

    public List<Player> show();
	public List<Player> searchBySkill(String skill) throws PlayerException;
}
