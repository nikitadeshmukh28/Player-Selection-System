package com.cg.ProjectSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
/**
 *  * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 * Using this annotation it will wraps commennly used annotation with spring boot.
 * it will also autoconfigures the whole framework.
 */
@SpringBootApplication
/**
 * this annotation used for scanning all beans in this package.
 * @author nikitadeshmukh
 *
 */
@ComponentScan("com.cg.ProjectSpringBoot")
public class ProjectSpringBootApplication {

	public static void main(String[] args) {
		/**
		 * This run() method will starts spring creates spring context and applies annotations and sets ups the container.
		 */
		SpringApplication.run(ProjectSpringBootApplication.class, args);
		System.out.println("hello");
	}

}
