package com.cg.ProjectSpringBoot.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.ProjectSpringBoot.dto.Player;

/**
 *  * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 * This is the Playerdao interface whish extends Jparepository and also contain some custom methods also.
 *
 *
 */
public interface PlayerDao extends JpaRepository<Player,Integer>{
	
	public Player findByPlayerId(int playerId);
	public List<Player> findBySkill(String skill);
	
}
