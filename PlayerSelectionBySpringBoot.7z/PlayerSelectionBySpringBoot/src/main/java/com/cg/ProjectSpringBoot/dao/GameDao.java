package com.cg.ProjectSpringBoot.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.ProjectSpringBoot.dto.Game;
/**
 *  * Written by Nikita on 25/05/2019
 * last Modified On 27/05/2019
 * This is the Gamedao interface which extends Jparepository and also contain some custom methods also.
 * 
 *
 */
public interface GameDao extends JpaRepository<Game,Integer>{

	public Game findByGameId(int gameId);
	public Game findByName(String name);
    
}
