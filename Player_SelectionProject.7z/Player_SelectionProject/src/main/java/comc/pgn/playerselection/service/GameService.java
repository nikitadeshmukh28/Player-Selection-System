package comc.pgn.playerselection.service;

import java.util.List;

import com.cg.playerselection.exceptions.GameException;

import comc.pgn.playerselection.dto.Game;

public interface GameService {
	public Game addGame(Game game);
	public List<Game> searchByName(String name) throws GameException;
	public List<Game>  showAll();}
