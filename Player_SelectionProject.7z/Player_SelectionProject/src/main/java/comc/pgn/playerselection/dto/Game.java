package comc.pgn.playerselection.dto;

import java.util.List;

public class Game {
	private String name;
	private List<Player> player;
	@Override
	public String toString() {
		return "Game [name=" + name + ", player=" + player + "]";
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<Player> getPlayer() {
		return player;
	}
	public void setPlayer(List<Player> player) {
		this.player = player;
	}
	public Game(String name, List<Player> player) {
		super();
		this.name = name;
		this.player = player;
	}
	public Game() {
		super();
	}
	public Game(String name) {
		super();
		this.name = name;
	}


}
