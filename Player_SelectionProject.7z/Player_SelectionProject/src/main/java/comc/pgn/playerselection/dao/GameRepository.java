package comc.pgn.playerselection.dao;

import java.util.List;

import com.cg.playerselection.exceptions.GameException;

import comc.pgn.playerselection.dto.Game;
public interface GameRepository {
	public boolean save(Game game);
	public List<Game> findByName(String name) throws GameException;
	public List<Game> findAll();
}
