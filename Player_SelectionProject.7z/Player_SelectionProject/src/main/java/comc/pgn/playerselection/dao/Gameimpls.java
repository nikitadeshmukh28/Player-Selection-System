package comc.pgn.playerselection.dao;

import java.util.ArrayList;
import java.util.List;

import com.cg.playerselection.exceptions.GameException;
import com.cg.playerselection.exceptions.PlayerException;
import com.cg.playerselection.util.DButil;

import comc.pgn.playerselection.dto.Game;
import comc.pgn.playerselection.dto.Player;

public class Gameimpls implements GameRepository{
	public boolean save(Game game) {
		DButil.games.add(game);
		return true;}
	public List<Game> findByName(String name) throws GameException {
		List<Game> gamesearch=new ArrayList<Game>();
		for(Game game:DButil.games) {
			if(game.getName().equals(name)) {
				gamesearch.add(game);
			}
		}
		if (gamesearch.isEmpty()) {throw new GameException("Game not Found");}
		return gamesearch;	}
	public List<Game> findAll() {
		return DButil.games;
	}
}
