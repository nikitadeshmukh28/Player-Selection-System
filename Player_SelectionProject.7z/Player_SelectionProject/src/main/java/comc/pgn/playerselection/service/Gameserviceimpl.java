package comc.pgn.playerselection.service;
import java.util.List;

import com.cg.playerselection.exceptions.GameException;

import comc.pgn.playerselection.dao.GameRepository;
import comc.pgn.playerselection.dao.Gameimpls;
import comc.pgn.playerselection.dto.Game;
public class Gameserviceimpl implements GameService {
	GameRepository dao;
	public Gameserviceimpl() {
		super();
		dao=new Gameimpls();}
	public List<Game> searchByName(String name) throws GameException {
		return dao.findByName(name);}
	public Game addGame(Game game) {
		dao.save(game);
		return game;}
	public List<Game> showAll() {
		return dao.findAll();}}






