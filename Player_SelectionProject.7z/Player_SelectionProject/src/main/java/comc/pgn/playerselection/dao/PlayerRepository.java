package comc.pgn.playerselection.dao;

import java.util.List;

import com.cg.playerselection.exceptions.PlayerException;

import comc.pgn.playerselection.dto.Player;

public interface PlayerRepository {
	public boolean save(Player p);
	public List<Player> findbyskill(String skill) throws PlayerException;
	public Player findById(int playerId) throws PlayerException;
	
}
