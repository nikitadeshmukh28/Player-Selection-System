package comc.pgn.playerselection.service;

import java.util.List;

import com.cg.playerselection.exceptions.PlayerException;

import comc.pgn.playerselection.dao.Gameimpls;
import comc.pgn.playerselection.dao.PlayerImpl;
import comc.pgn.playerselection.dao.PlayerRepository;
import comc.pgn.playerselection.dto.Player;

public class PlayerServiceImpl implements PlayerService{
	PlayerRepository dao;
	public PlayerServiceImpl() {
		super();
		dao = new PlayerImpl();}
	public Player addPlayer(Player p) {
		dao.save(p);
		return p;}
	public Player searchById(int playerId) throws PlayerException {
		return dao.findById(playerId);}
	public List<Player> searchBySkill(String skill) throws PlayerException {
		return dao.findbyskill(skill);}
	
}
