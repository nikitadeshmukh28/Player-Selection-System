package comc.pgn.playerselection.dao;

import java.util.ArrayList;
import java.util.List;
import com.cg.playerselection.exceptions.PlayerException;
import com.cg.playerselection.util.DButilPlayer;

import comc.pgn.playerselection.dto.Player;
public class PlayerImpl implements PlayerRepository{

	public boolean save(Player p) {
		DButilPlayer.playerlist.add(p);
		return true;
	}
	public List<Player> findbyskill(String skill) throws PlayerException {
		List<Player> playersearch=new ArrayList<Player>();
		for(Player p:DButilPlayer.playerlist) {
			if(p.getSkill().equals(skill)) {
				playersearch.add(p);} 
		}
		if (playersearch.isEmpty()) {throw new PlayerException("Player not found for this skill");}
		return playersearch;
	}
	public Player findById(int playerId) throws PlayerException{
		for(Player p:DButilPlayer.playerlist) 
			if(p.getPlayerId()==(playerId)) 
				return p;
			throw new PlayerException("Id not Found");	
			
	}		
}	

