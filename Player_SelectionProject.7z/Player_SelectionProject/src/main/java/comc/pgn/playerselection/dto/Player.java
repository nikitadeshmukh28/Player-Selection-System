package comc.pgn.playerselection.dto;

public class Player {
	private String name;
	private int playerId;
	private String skill;
	public Player() {
		super();
	}
	public Player(String name, int playerId, String skill) {
		super();
		this.name = name;
		this.playerId = playerId;
		this.skill = skill;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getPlayerId() {
		return playerId;
	}
	public void setPlayerId(int playerId) {
		this.playerId = playerId;
	}

	public String getSkill() {
		return skill;
	}
	public void setSkill(String skill) {
		this.skill = skill;
	}
	@Override
	public String toString() {
		return "Player [name=" + name + ", playerId=" + playerId  + ", skill=" + skill + "]";
	}


}
