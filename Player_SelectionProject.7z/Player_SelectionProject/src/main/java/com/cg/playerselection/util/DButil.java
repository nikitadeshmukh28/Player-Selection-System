package com.cg.playerselection.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import comc.pgn.playerselection.dto.Game;
public class DButil{
	private DButil() {}
	public static List<Game> games=new ArrayList<Game>();}