package com.cg.playerselection.util;
import java.util.ArrayList;
import java.util.List;
import comc.pgn.playerselection.dto.Game;
import comc.pgn.playerselection.dto.Player;
public class DButilPlayer {
	public static List<Player> playerlist=new ArrayList<Player>();
	static {
		Player p=new Player("niki",100,"Cricket");
		Player pone=new Player("Tanuja",101,"Kabaddi");
		Player ptwo=new Player("Rishi",102,"Hollyball");
		Player pthree=new Player("Abcd",103,"Cricket");
		playerlist.add(pone);
		playerlist.add(p);
		playerlist.add(ptwo);
		playerlist.add(pthree);
		}}
