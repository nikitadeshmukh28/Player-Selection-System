
package com.cg.playerselection.ui;
import java.util.List;
import java.util.Scanner;
import com.cg.playerselection.util.DButil;
import com.cg.playerselection.util.DButilPlayer;
import comc.pgn.playerselection.dto.Game;
import comc.pgn.playerselection.dto.Player;
import comc.pgn.playerselection.service.Gameserviceimpl;
import comc.pgn.playerselection.service.PlayerServiceImpl;

public class MyApplication {
	static Gameserviceimpl service;
	static PlayerServiceImpl serviceone;
	public MyApplication() {

	}
	public static void main(String args[]) {
		Scanner scr=new Scanner(System.in);
		service=new Gameserviceimpl();
		serviceone=new PlayerServiceImpl();
		int choice=0;
		do {
			printDetails();
			System.out.println("Enter your choice");
			System.out.println("*****************************************************");
			choice=scr.nextInt();
			switch(choice) {

			case 1:
				System.out.println("Enter Game Name");
				String name=scr.next();
				System.out.println("The list of players");
				try {
				List<Player> player=serviceone.searchBySkill(name);
		 Game game=new Game(name, player);
		 System.out.println(service.addGame(game));
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}
				
				break;

			case 2: 
				List<Game> mylist=service.showAll();
				for(Game gameData:mylist) {
					System.out.println(gameData.getName()+ gameData.getPlayer());
					System.out.println("\n");
				}
				break;
				
			case 3:
				System.out.println("Enter the Game to search by Name");
				String gname=scr.next();
				try {
					List<Game> games=service.searchByName(gname);
					List<Player> players=serviceone.searchBySkill(gname);
					for(Game gameAll:games) {
						System.out.println("Name is "+gameAll.getName());}
					System.out.println("   the players matches for the game are");
					for(Player playerAll:players) {
						System.out.println(playerAll.getName());
					}
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}break;


			case 4:
				System.out.println("Enter Player Name");
				String pname=scr.next();
				System.out.println("Enter Player Id");
				int playerId=scr.nextInt();
				System.out.println("Enter Player Skill");
				String skill=scr.next();
				Player p=new Player();
				p.setName(pname);
				p.setPlayerId(playerId);
				p.setSkill(skill);
				
						serviceone.addPlayer(p);

				break;
			case 5:
				System.out.println("enter any game name as skill whose player you want:");
				String skill1=scr.next();
				try {
					List<Player> players=serviceone.searchBySkill(skill1);
					System.out.println("The players with this skill are"+players);
				} catch (Exception e) {
					System.out.println(e.getMessage());
				}break;
			case 6:		
				System.out.println("Enter the player id to search");
				int sid=scr.nextInt();
				try {
					Player prosearch=serviceone.searchById(sid);
					if(prosearch!=null) {	
						
						System.out.println(prosearch);
					}
				}catch (Exception e) {
					System.out.println(e.getMessage());
				}break;	
			default:
				System.out.println("Invalid Choice");
			}	
		}while(choice!=7);

	}
	private static void printDetails() {
		System.out.println("1.add game");
		System.out.println("2.Show All Game");
		System.out.println("3.Search game by Name");
		System.out.println("4.Add Player");
		System.out.println("5.Search player by skill");
		System.out.println("6.Search Player By Id");

	}}
